# PC-BRANCH-LOGO-IDO — real D19 ASK → rank-dispatch integration QA

**Scope:** Existing Stage 2, QA branch only. This is a bounded Native integration test of the real D19 ASK stream into the QA candidate `monster.stage02.choose.rank`. It is not full Stage 2 acceptance, a calendar conversion, a year/cutlet/month/weaving candidate-algorithm test, or a final 5-tuple test.

## Provenance and isolation

- Canonical `Logo+Ido` remains `ad001c6aeeb6c758f5004b206a656fec5d6fc403`; no canonical, `main`, merge, release, or policy change is authorized.
- QA parent is `c21646e1b06f25b3f75fb672dd432ead8e664875`, whose parent is the isolated names rank/unrank candidate `43e0b54bde74df8535efaf356b5df8da183a7988`. This integration commit is a child of the existing QA composition head; it changes no `src/` or `test/` file.
- The workflow pins UCBLogo 6.2.5 to `a0215433f07384e4c42fe247525867f11e6f32f7`, verifies exact `GITHUB_SHA`, exact parent, unchanged source/test tree, and the live canonical ref. Every job preserves source blob IDs, QA file hashes, Native log, host log, exit code, elapsed seconds, and generated runner.
- Frozen source blobs at the QA parent: `src/exact_integer.logo` `f2c1a8aa5822423402cd5825255891183f0fc83c`; `src/stage02_sauce.logo` `f74fd03fbccab378dfc5999f5d40ede0cc94fa88`; `src/stage02_ask.logo` `8e15fa48c9e7f83d1df54aeb0929216945852e36`; `src/stage02_choose_rank.logo` `116cab31f3afd03b3a03a8981cef740c193c727b`; `test/normative_reference.logo` `625171ecd5fd93fb8381686f2b2f6b29ed3649cf`. The workflow records the complete `src/` and `test/` blob manifest.
- The independent Python oracle is newly authored for this integration. It does not import Logo code, the normative reference, or any prior branch fixture. The Native test uses the frozen `test/normative_reference.logo` only to obtain the expected ASK stream and the exact call-site N inputs.

## Case design: 18 cases, 10 isolated jobs

Frozen call-site map in `test/normative_reference.logo` (blob `625171ecd5fd93fb8381686f2b2f6b29ed3649cf`): `nr.gate.gap` line 670; `nr.gate.cover` 711; `nr.year5000.scan.i` 799; `nr.year5000` 825; `nr.next.year` 846; `nr.previous.year` 866; `nr.choose.cutlet.count` 899; `nr.choose.cutlet.partition` 907; `nr.choose.month.count` 944; `nr.choose.month.lengths` 956; `nr.choose.weaving` 965.

The two actual raw date pairs are `(nr.foundation, nr.tablets)` and `(nr.tablets, nr.foundation)`. In the frozen integer source these are `-15,055,671` and `-278,522`, respectively (a 14,777,149-day separation), which fixes the first gate-extension direction described below. Each direction has nine cases:

1. `ASK(1,1)` — the first gate extension used by `nr.gate.cover`: backward index `-1` for foundation→tablets; forward index `+1` for tablets→foundation. Exact call-site sauce is `nr.sauce nr.foundation (nr.foundation + signedStep)` and exact `N=922`.
2. `ASK(1,10)` — `nr.year5000` call-site sauce `(calculationDay, calculationDay)`; `N` is the count of the sorted `nr.year5000.scan.i` candidate pairs after equivalent exact gate coverage.
3. `ASK(1,11)` — `nr.next.year` call-site sauce `(calculationDay, nr.gate.ensure openIndex)`; `N=count(nr.next.candidates openIndex (openIndex+1))`.
4. `ASK(1,12)` — `nr.previous.year` call-site sauce `(calculationDay, nr.gate.ensure closeIndex)`; `N=count(nr.previous.candidates closeIndex (closeIndex-1))`.
5–9. The five `nr.build.structure` call-site selectors use the exact structure sauce `(calculationDay, firstDay)`, where `firstDay=nr.year.open.day(year)+1`. The structure job uses the immediate adjacent reference year selected from the `nr.year5000` anchor (next for foundation→tablets, previous for tablets→foundation); this deliberately avoids claiming that the full `nr.find.year` traversal or target-year selection was tested.
   - `ASK(2,20)`: `N=count(nr.cutlet.count.candidates 6 gaps)`.
   - `ASK(2,21)`: `N=nr.cp.count G K 0 "false required`, with `G`, `K`, and `required` taken from the normative partition call site.
   - `ASK(3,30)`: `N=count(nr.range minMonths maxMonths)`.
   - `ASK(3,31)`: `N=nr.bc.count L monthCount 4 123`.
   - `ASK(4,32)`: `N=nr.weave.count lengths 0 0`.

This gives 9 selector/context cases per raw pair, 18 total. Both `next` and `previous` call sites are independently exercised from the same `nr.year5000` anchor in each direction; the structure case uses the direction-appropriate adjacent year. No full calendar route is inferred from these calls.

The reverse raw date is much farther from the foundation gate than the forward date. To avoid the frozen reference's quadratic scan over every intervening gate index, `ad.year5000.data` uses the same `nr.gate.gap` recurrence and `nr.year5000.scan.i`/`nr.year.valid.pair` predicates but scans only a mathematically complete local window: `anchor±139`, where `anchor=nr.gate.binary.before(calculationDay)`. The minimum gate gap is 42 (`41+rank`, with `1<=rank<=922`), and a valid year is at most 5778 days, so no valid pair can span more than `floor(5778/42)=137` gate indices. The 139-index radius therefore contains every candidate pair and covers the full ±5778-day gate window; the test also verifies the resulting gate days cover `calculationDay±5778`. The helper extends gates iteratively with the exact frozen `nr.gate.extend.forward/backward` reporters, then uses the exact frozen candidate predicate and sorting. It does not alter the reference, fabricate sauce, or accept a year-selection algorithm; it only bounds the reference scan used to obtain the call-site N.

The ten Native jobs split the five context families (`gate`, `year5000`, `next`, `previous`, `structure`) across the two raw-pair directions. Each job builds exactly one production sauce context, compares its six bowls and final order/latch to the corresponding frozen `nr.sauce`, and runs one or five selectors. The Native timeout is 1,200 seconds per job; workflow job timeout is 25 minutes to leave time for build and artifact upload.

## Per-case assertions and independent oracle

Each case records 14 Native checks:

- production context status is `SAUCE_ONLY`;
- production sauce bowls equal frozen reference bowls;
- production final order/latch equals frozen reference order;
- production ASK result has exactly two fields;
- first value is canonical BI and lies in `[1,M]`;
- step is exactly `+1` or `-1`;
- first value equals frozen `nr.ask` first value;
- step equals frozen `nr.ask` step;
- N is canonical BI and strictly positive;
- dispatcher rank is canonical BI and lies in `[1,N]`.

The Native total is 18 cases × 14 checks = 252 checks. The independent Python-int oracle reads only the logged first value, step, N, and dispatcher rank. With `M=2^127-1`, it independently constructs the minimum-width base-M sample, computes `space=M^k` and `cutoff=floor(space/N)*N`, and compares the expected rank to the Native rank. On rejected suffixes it uses the mathematically exact endpoint (rank 1 for positive wrap, rank N for negative walk). A separate small-base exhaustive walker validates this shortcut against explicit candidate-by-candidate rejection.

Each host case adds five checks (input bounds, step domain, positive N, rank range, and exact Python-int rank equality), for at least 18 × 19 = 342 total Native+host checks across the ten jobs. The host self-test covers bases 2..7 and must print its case count and `ASK_DISPATCH_HOST_ORACLE=PASS`.

## Acceptance boundary

- A job is accepted only from its completed run/job, exact SHA, Native log markers, `exit.txt=0`, elapsed time, host oracle log, and downloaded artifact whose SHA-256 and ZIP CRC are verified.
- All ten jobs must be completed successfully on the same integration SHA before the 18-case integration QA is marked PASS.
- Partial or queued jobs are not PASS and are not blockers; do not dispatch a duplicate run.
- This result does not promote the dispatcher, does not complete Stage 2, and does not authorize canonical source changes, `main`, merge, Stage 3, or publication.

**Expected checkpoint after implementation:** `D=פתוחה`, `G=READY`; NEXT is exact-SHA review of the ten Native jobs, logs, and artifacts.
