#!/usr/bin/env python3
"""Independent Python-int oracle for the QA-only Logo D19->rank dispatcher gate."""
from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path

M = (1 << 127) - 1
BASE10000 = 10_000


def bi_digits_to_int(words: list[str], label: str) -> int:
    if not words:
        raise ValueError(f"{label}: empty BI digit vector")
    digits = [int(word, 10) for word in words]
    if any(d < 0 or d >= BASE10000 for d in digits):
        raise ValueError(f"{label}: digit outside base-10000 range")
    if len(digits) > 1 and digits[-1] == 0:
        raise ValueError(f"{label}: non-canonical high zero")
    return sum(d * (BASE10000 ** i) for i, d in enumerate(digits))


def dispatcher_rank(first_value: int, step: int, n: int, modulus: int = M) -> int:
    """Independent base-M construction, integer cutoff, and suffix endpoint."""
    if not (1 <= first_value <= modulus):
        raise ValueError("first value outside 1..M")
    if step not in (-1, 1):
        raise ValueError("step must be +/-1")
    if n < 1:
        raise ValueError("N must be positive")

    width = 1
    space = modulus
    while space < n:
        space *= modulus
        width += 1

    # Construct the k base-M digits from the consecutive cyclic ASK stream.
    low_to_high = [((first_value - 1 + step * offset) % modulus) for offset in range(width)]
    sample_minus_one = 0
    for digit in reversed(low_to_high):
        sample_minus_one = sample_minus_one * modulus + digit
    sample = sample_minus_one + 1

    cutoff = (space // n) * n
    if sample > cutoff:
        # The rejected region is one contiguous suffix of the k-digit circle.
        sample = 1 if step == 1 else cutoff
    return ((sample - 1) % n) + 1


def brute_rank(first_value: int, step: int, n: int, base: int) -> int:
    """Small-circle oracle: walk every rejected sample, without suffix shortcut."""
    width = 1
    space = base
    while space < n:
        space *= base
        width += 1
    digits = [((first_value - 1 + step * offset) % base) for offset in range(width)]
    sample = 1 + sum(digit * (base ** i) for i, digit in enumerate(digits))
    cutoff = (space // n) * n
    for _ in range(space):
        if sample <= cutoff:
            return ((sample - 1) % n) + 1
        sample = 1 + ((sample - 1 + step) % space)
    raise AssertionError("full sample circle contained no accepted point")


def run_small_selftest() -> int:
    tested = 0
    for base in range(2, 8):
        for n in range(1, base ** 3 + 1):
            for first_value in range(1, base + 1):
                for step in (-1, 1):
                    fast = dispatcher_rank(first_value, step, n, base)
                    slow = brute_rank(first_value, step, n, base)
                    if fast != slow:
                        raise AssertionError(
                            f"small differential mismatch: base={base}, a={first_value}, "
                            f"step={step}, N={n}, fast={fast}, slow={slow}"
                        )
                    tested += 1
    return tested


def expected_tags(direction: str, group: str) -> list[str]:
    if group == "gate":
        return [f"gate_{direction}"]
    if group == "year5000":
        return [f"year5000_{direction}"]
    if group == "next":
        return [f"next_{direction}"]
    if group == "previous":
        return [f"previous_{direction}"]
    if group == "structure":
        return [
            f"cutlet_count_{direction}",
            f"cutlet_partition_{direction}",
            f"month_count_{direction}",
            f"month_lengths_{direction}",
            f"weaving_{direction}",
        ]
    raise ValueError(f"unknown group: {group}")


def parse_native_log(log_text: str, direction: str, group: str) -> list[tuple[str, int, int, int, int]]:
    lines = log_text.splitlines()
    modulus_lines = [line.split() for line in lines if line.startswith("ASK_DISPATCH_MODULUS ")]
    if len(modulus_lines) != 1:
        raise ValueError(f"expected one modulus marker, found {len(modulus_lines)}")
    modulus = bi_digits_to_int(modulus_lines[0][1:], "modulus")
    if modulus != M:
        raise ValueError(f"Logo modulus mismatch: got {modulus}, expected 2^127-1")

    cases = []
    for line in lines:
        if not line.startswith("ASK_DISPATCH_ROW "):
            continue
        words = line.split()
        if len(words) < 9 or words[0] != "ASK_DISPATCH_ROW":
            raise ValueError(f"malformed row: {line}")
        tag = words[1]
        step = int(words[2], 10)
        try:
            a_marker = words.index("A")
            n_marker = words.index("N")
            r_marker = words.index("R")
        except ValueError as exc:
            raise ValueError(f"missing A/N/R marker: {line}") from exc
        if not (a_marker == 3 and a_marker < n_marker < r_marker):
            raise ValueError(f"misordered A/N/R markers: {line}")
        first_value = bi_digits_to_int(words[a_marker + 1:n_marker], f"{tag}.first")
        n = bi_digits_to_int(words[n_marker + 1:r_marker], f"{tag}.N")
        rank = bi_digits_to_int(words[r_marker + 1:], f"{tag}.rank")
        cases.append((tag, step, first_value, n, rank))

    wanted = expected_tags(direction, group)
    observed = [case[0] for case in cases]
    if len(observed) != len(wanted) or sorted(observed) != sorted(wanted):
        raise ValueError(f"case tags mismatch: observed={observed}, expected={wanted}")
    if len(set(observed)) != len(observed):
        raise ValueError("duplicate case tag")

    expected_case_count = len(wanted)
    expected_check_count = 14 * expected_case_count
    if f"ASK_DISPATCH_CASES_PASIS {expected_case_count}" not in lines:
        raise ValueError("Native case-count marker missing or incorrect")
    if f"ASK_DISPATCH_CHECKS_PASIS {expected_check_count}" not in lines:
        raise ValueError("Native check-count marker missing or incorrect")
    if "ASK_DISPATCH_NATIVE_PASIS" not in lines:
        raise ValueError("Native PASS marker missing")
    if any(re.search(r"ASK_DISPATCH_.*FAILURE", line) for line in lines):
        raise ValueError("Native failure marker present")
    return cases


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--log", required=True, type=Path)
    parser.add_argument("--direction", required=True, choices=("forward", "reverse"))
    parser.add_argument("--group", required=True, choices=("gate", "year5000", "next", "previous", "structure"))
    args = parser.parse_args()

    selftest_cases = run_small_selftest()
    cases = parse_native_log(args.log.read_text(encoding="utf-8", errors="strict"), args.direction, args.group)
    width_counts: dict[int, int] = {}
    checks = 0
    for tag, step, first_value, n, actual_rank in cases:
        if not (1 <= first_value <= M):
            raise ValueError(f"{tag}: first value outside 1..M")
        if step not in (-1, 1):
            raise ValueError(f"{tag}: step outside +/-1")
        if n < 1:
            raise ValueError(f"{tag}: N is not positive")
        if not (1 <= actual_rank <= n):
            raise ValueError(f"{tag}: rank outside 1..N")
        expected_rank = dispatcher_rank(first_value, step, n)
        if actual_rank != expected_rank:
            raise ValueError(
                f"{tag}: Python-int oracle mismatch: actual={actual_rank}, expected={expected_rank}, "
                f"step={step}, N={n}"
            )
        width = 1
        space = M
        while space < n:
            space *= M
            width += 1
        width_counts[width] = width_counts.get(width, 0) + 1
        checks += 5

    width_text = ",".join(f"k{width}:{width_counts[width]}" for width in sorted(width_counts))
    print(f"ASK_DISPATCH_HOST_SELFTEST_CASES={selftest_cases}")
    print(f"ASK_DISPATCH_HOST_CASES={len(cases)}")
    print(f"ASK_DISPATCH_HOST_CHECKS={checks}")
    print(f"ASK_DISPATCH_HOST_WIDTHS={width_text}")
    print("ASK_DISPATCH_HOST_ORACLE=PASS")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:  # make the CI evidence explicit on any failure
        print(f"ASK_DISPATCH_HOST_ORACLE=FAIL: {exc}", file=sys.stderr)
        raise SystemExit(1)
