
namespace pastafari {
bool qaCorruptSharedGateDay(const Integer& index) {
    std::lock_guard<std::mutex> guard(gateGraveyardMutex);
    auto it=gateGraveyard.find(GateGraveyardKey{true,index});
    if(it==gateGraveyard.end() || it->second.poisoned)return false;
    it->second.day+=1;
    return true;
}
}
