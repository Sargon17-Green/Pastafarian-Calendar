
namespace pastafari {
bool qaInjectCompetingInterval(const Integer& c, bool insert) {
    std::lock_guard<std::mutex> guard(ancestralMemoryVaultMutex);
    for (auto it=ancestralMemoryVault.begin();it!=ancestralMemoryVault.end();++it) {
        const auto& k=it->first;
        if (!k.stage56 || k.calculationDay!=c ||
            k.yearNumber!=(insert?Integer{5000}:Integer{987654321})) continue;
        if (!insert) { ancestralMemoryVault.erase(it); return true; }
        auto key=k;
        auto value=it->second;
        if (value.poisoned) return false;
        key.yearNumber=987654321;
        value.yearNumber=key.yearNumber;
        value.certifiedTarget.number=key.yearNumber;
        return ancestralMemoryVault.emplace(key,value).second;
    }
    return false;
}
}
