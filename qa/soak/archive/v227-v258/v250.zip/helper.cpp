
namespace pastafari {
bool qaCorruptSharedGate(const Integer& index,int kind) {
    std::lock_guard<std::mutex> guard(gateGraveyardMutex);
    auto it=gateGraveyard.find(GateGraveyardKey{true,index});
    if(it==gateGraveyard.end() || it->second.poisoned)return false;
    if(kind==0)it->second.semanticFingerprint="QA_WRONG_FINGERPRINT";
    else if(kind==1)it->second.day=FOUNDATION_DAY_OLD;
    else if(kind==2) {
        // A small corruption which should pass the cheap range
        // check but not the full historical recomputation.
        it->second.day+=1;
    } else return false;
    return true;
}
}
