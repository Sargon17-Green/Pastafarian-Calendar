# מילון סטטוסים ששימש במחקר

- **FORMAL-VERIFIED** — theorem/definition נבנה בהצלחה ב-Lean וה-root הרלוונטי עבר.
- **MANUAL-PROVED** — הוכחה מתמטית ידנית, לא proof-assistant theorem.
- **MACHINE-AUDITED** — בדיקה סופית/רחבה במחשב; אינה הוכחה אוניברסלית אלא אם
  כיסתה במפורש מרחב סופי מלא.
- **EMPIRICAL** — תצפית על samples/windows.
- **HEURISTIC** — כיוון/השערה שלא הוכחה.
- **SOURCE-AUDITED** — התאמה שנבדקה מול source נורמטיבי, אך לא theorem על semantics שלו.
- **proof-engineering failure** — כשל parser/elaborator/API/tactic, ללא counterexample.
