# ממצאים אמפיריים ו-MACHINE-AUDITED

יש להפריד אותם מהמשפטים הפורמליים.

## Non-affinity / low-degree elimination
ב-state transition הקומפקטי:
- recurrence אפינית דו-ממדית נשללה במדגם c=739862.
- polynomial degree ≤5 לא התאים ל-32 states.
- נבדקו ונשללו במדגמים משפחות פשוטות נוספות:
  PGL(3), rational low-degree, simple periods/memory/low-q automata.

מעמד: MACHINE-AUDITED / EMPIRICAL, לא universal proof.

## Cold jump
ה-state הטבעי בזנב:
`(r,z) = (index mod B, response residue mod B)`.
גודל אפקטיבי: 254 bits.

מעבר שנה אחת צורך לכל היותר 137 local gaps + Sauce selection.

לא נמצאה closed-form affine/low-degree jump.
האפשרות של conjugacy לא-לינארית או summary עשיר יותר לא נשללה פורמלית.

## fixed-c year-5000 probe
עבור c=739862:
- year length 5341;
- 7 cutlets;
- 45 months;
- target range 735718..741058;
- 50,271 posting checks PASS.

## same-t cross-c collision
נמצא אמפירית witness:
`F(739863,739057) = F(739864,739057) = (5000,5,320,12,65)`.
יש להתייחס אליו כ-normative-pending אלא אם הוא אומת בנפרד בארטיפקט ה-validator.

## information theory
עבור c=739862, Y=5000, W=5341:
- H(T)=12.382894 bits.
- dK: 10.379304 bits.
- dM: 6.930432 bits.
- M: 5.490570 bits.
- K: 2.502791 bits.
- residual של (dK,dM): 0.007115 bits.
Shapley:
- K 1.056649
- dK 5.211647
- M 2.845571
- dM 3.269027
