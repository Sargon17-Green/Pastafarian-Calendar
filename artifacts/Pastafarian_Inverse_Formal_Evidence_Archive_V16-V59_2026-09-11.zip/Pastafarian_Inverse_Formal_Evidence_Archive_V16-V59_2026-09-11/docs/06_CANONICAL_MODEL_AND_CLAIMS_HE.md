# המודל הקאנוני וגבולות הטענה

## מקור נורמטיבי שננעל במהלך המחקר
Repository:
`Sargon17-Green/Pastafarian-Calendar`

Pinned commit ששימש לביקורת:
`78eb29ae0b1fd67ccbaf02e336482eafcc89d9d0`

Reference file:
`tests/normative-reference.js`

## קבועים ונוסחאות שנכנסו למודל
- `B = 2^127 - 1`.
- `SAVE(x)=1+regularMod(x-1,B)`.
- workCounts: action/target/distance/connection/direction.
- STONES initial row `[17,29,43,71,101]` וה-recurrence שנקבעה.
- 7 hidden coefficient rows.
- 11 visible grind tuples.
- 46 visible drops.
- bowl primes `[17,19,23,29,31,37]`, עם prime squared באתחול.
- 12 final post-stirs.
- askBowl bowl 1, previous-year seal 12, next-year seal 11.
- chooseRankShort.
- gate gap `41 + chooseRank(...,922)`.
- 720 lexicographic six-bowl orders.

## Decoder
V36 מוכיח בתוך Lean:
- 720 rows הן permutations חוקיות;
- inverse laws;
- כל row שווה ל-factoradic lexicographic unranking המתאים;
- `fullyConcretePipeline` אינו מכיל עוד decoder חיצוני.

## נקודת זהירות קריטית
לא נבנה semantics פורמלי של JavaScript, parser של הקובץ הנורמטיבי, או theorem
שמקבל את source text של JS ומוכיח שקילות למודל Lean.

לכן:
- הטענות על המודל Lean עצמו הן FORMAL-VERIFIED.
- הטענה שזו transcription מדויקת של ה-JS היא SOURCE-AUDITED / MANUAL-AUDITED.
- אין לקרוא לכך "formal verification of the JavaScript source" ללא שכבת bridge נוספת.

זהו גבול הטענה החשוב ביותר שנשאר אחרי V59.
