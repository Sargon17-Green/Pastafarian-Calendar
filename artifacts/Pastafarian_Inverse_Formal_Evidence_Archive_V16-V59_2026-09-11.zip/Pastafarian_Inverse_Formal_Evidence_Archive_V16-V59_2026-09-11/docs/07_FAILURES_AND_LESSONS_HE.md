# כשלים, retries ולקחים

מרבית הכשלים בסדרה לא היו counterexamples מתמטיים אלא בעיות proof-engineering.

## דפוסים שחזרו
- parser / reserved identifiers.
- UTF-8 BOM ב-BAT או בקובץ Lean.
- nested-comment token.
- `simp made no progress`.
- missing theorem/API names.
- namespace resolution.
- typeclass synthesis (`DecidablePred`).
- `maxRecDepth` בזמן normalization של dependent structures/projections.
- wrappers שפתחו term ענק אף שהתוכן הישיר היה פשוט.

## שינוי אסטרטגיה מוצלח
החל מ-V42 עברנו מחבילות זעירות ל-heavy tranches:
- מספר modules בכל הרצה;
- stage-by-stage PASS/FAIL;
- downstream stages skipped אחרי כשל;
- source snapshots נאספו לעיתים באותה ריצה.

## wrappers שנזנחו
במקום להילחם ב-dependent wrappers:
- הוגדר direct canonical selector;
- הוגדר direct concrete transition;
- הוכחו quotient/finite-orbit facts עליהם ישירות.

הדבר צמצם elaborator pathologies בלי לשנות את הנוסחה המתמטית.

## V53
לא הגיע כלל ל-Lean:
- BAT BOM;
- PowerShell parser error.
הוחלף ב-V54.

## optional rawStep bridge
ה-bridge הדפיניציוני הישיר ל-generic `rawStep` נתקע ב-maxRecDepth.
הוא נשאר non-green ולא נכלל ב-root הסופי.
התוצאות המהותיות אינן תלויות בו.
