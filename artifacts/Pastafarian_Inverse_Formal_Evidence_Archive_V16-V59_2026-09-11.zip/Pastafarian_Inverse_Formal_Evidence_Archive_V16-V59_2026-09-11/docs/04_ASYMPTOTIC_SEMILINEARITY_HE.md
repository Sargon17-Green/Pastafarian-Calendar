# מחזוריות, זנבות וסמילינאריות

## Tail periodicity
ל-c קבוע, כאשר t רחוק מספיק:
- Sauce תלוי ב-target רק modulo B;
- gate-gap sequence הוא B-periodic;
- ההיטל ללא Y הוא eventually periodic;
- Y ממשיך affine-linear לאורך tail.

ספי remote מפורשים:
- past: `t ≤ min(Foundation,c) - 5778`.
- future: `t ≥ max(Foundation,c) + 5779`.

## Fixed-c fibers
לכל pattern ללא Y:
- הסיב המדויק הוא finite center + finite union של one-sided arithmetic progressions.
עם exact Y:
- הסיבים finite.

## Diagonal translation
כאשר c,t נמצאים באותו צד הרחוק של Foundation,
הזזה סימולטנית ב-B שומרת את ה-Sauce ואת רכיבי nonyear ומתורגמת באופן affine ב-Y.
מכאן:
- קיימים גלובלית סיבים אינסופיים בני מנייה;
- unrestricted pair inversion אינו חד-ערכי באופן כללי.

## כל 31 תתי-הקבוצות
כל 31 תתי-הקבוצות הלא-ריקות של `(Y,K,dK,M,dM)` סווגו.
מעמד הסיווג:
**MANUAL-PROVED conditional on the audited/formal tail stack**, לא theorem יחיד ב-Lean.

- 16 subsets עם Y: exact-Y diagonals/finite fibers.
- 15 subsets בלי Y: periodic tails + weighted crossing + finite central strips.
- כל fiber לכל subset הוא semilinear.
- multiplicity גלובלי מקסימלי: aleph_0.
- לכל subset יש witness לסיבים בני מנייה עקב diagonal translation.

## Weighted orbit crossing
ה-core האבסטרקטי formalized.
למשקולות eventually-periodic בוצע MACHINE-AUDIT רחב:
1,712,856 / 1,712,856 PASS.
היישום הקלנדרי המלא נשען על tail bridges שנסגרו בהמשך השרשרת.
