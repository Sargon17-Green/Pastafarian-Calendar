# שרשרת ההוכחה הפורמלית — תמונת מצב

להלן השכבות העיקריות שהגיעו ל-PASS ולפיכך הן FORMAL-VERIFIED בתוך Lean.

## יסודות
- Arithmetic / SAVE / modulo-B infrastructure.
- GatePeriodicity.
- SauceCongruence.
- FiniteOrbit.
- WorkCounts tail facts.
- CycleLowerBound.

## Sauce וה-pipeline
- `CanonicalSauceBridge`: primitives של hidden/visible/bowl/post-stir.
- `CanonicalSaucePipeline`: composition וה-congruence.
- `TailSaucePeriodicity`.
- `CanonicalStones`: recurrence המדויקת של חמשת ה-STONES.
- `ConcreteSauceExecution`: 46 visible rounds + 12 post-stirs.
- `VisibleTimelineBridge`: סדר 46 הפלטים וקריאת timelineDrop.
- `CanonicalConcretePipeline`: 7 HiddenSpecs + 46 VisibleSpecs + 6 BowlSpecs.
- `CanonicalPermutationDecoder`: טבלת 720 + inverse laws + התאמה ל-factoradic lexicographic unrank.
- `fullyConcretePipeline`: אין יותר פרמטר decoder.
- `FullyConcreteTailBridge`: representative-independence ו-tail periodicity של ה-Sauce הקונקרטי.

## askBowl / gate / family
- `CanonicalAskBowlBridge`.
- `CanonicalLatchedOrder`.
- exact first-accepted semantics של `chooseRankShort` עבור N=922.
- procedural gate gap = closed gate gap.
- gate range `42..963`.
- B-periodicity של gate streams/offsets/accepted answers.
- `CanonicalYearGapBridge`.
- exact greatest candidate `smax`, עם `6 ≤ smax ≤ 137`.
- exact candidate interval.
- direct canonical selector מתוך `familyFromSmax + firstAnswer + directionStep + selectedGap`.
- concrete residue SauceView representatives.

## compact transition
- fully concrete direct step:
  `(r,z) -> (r+s, z-L_s(r))`
  כאשר `s` הוא ה-selected branch הקאנוני.
- equivariance ב-r וב-z modulo B.
- induced map על `Fin(B)^2`.
- finite-orbit repeat.
- quotient well-definedness.
- commuting square:
  `project(step x) = finiteStep(project x)`.
- correspondence לכל iterate.
- העברת finite collision חזרה ל-raw orbit כ-`CompactEq`.

## cycle closure
- chronological selected-step ledger.
- step bounds `6..137`.
- first-coordinate displacement = sum of selected branch sizes.
- כל nonzero compact return דורש לפחות `CycleLB` transitions.
- repeat gap של החזרה שקיימת ≥ `CycleLB`.
- `MinCycleDays` corollary תחת חסם 252 ימים לכל transition.

## V59 — משטח המשפטים הסופי
- `positive_tail_final`
- `negative_tail_final`
- `both_tails_final`
- `both_project_iterates`
- `final_exact_constants`

## הוכחות שנזנחו במכוון
`CanonicalDirectRawStepBridge` — bridge דפיניציוני חזרה ל-wrapper הגנרי `rawStep`
נתקע ב-maxRecDepth. הוא אינו נחוץ לתוצאות הסופיות משום שה-dynamics הישיר,
ה-quotient וה-orbit correspondence הוכחו ישירות.
