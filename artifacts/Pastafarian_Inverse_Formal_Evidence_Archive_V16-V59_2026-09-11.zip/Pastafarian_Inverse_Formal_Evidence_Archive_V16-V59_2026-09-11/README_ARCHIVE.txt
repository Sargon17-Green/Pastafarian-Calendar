Pastafarian Calendar — Inverse/Formal Evidence Archive
Lean proof stack V16–V59
Archived: 2026-09-11

Purpose
-------
Compact off-machine archive of the formal-proof evidence needed to preserve and
reconstruct the final V59 proof-stack state without retaining the much larger
research handoff and duplicated exploratory artifacts.

Included
--------
- packages/lean/ : all preserved Lean tranche packages from V16 through V59.
- evidence/results/ : run/result logs for the proof-stack progression.
- evidence/final/ : canonical final V58/V59 result logs.
- manifests/ : final state, chronology, manifest and source SHA-256 ledger.
- docs/ : final executive/formal status summaries and caveats.

Intentionally omitted
---------------------
- Large research_artifacts/ population/corpus files.
- Intermediate research-update ZIPs and duplicated exploratory notes.
- Duplicate RESULT_V58/RESULT_V59 copies from evidence/results; canonical copies
  are retained in evidence/final.

Important epistemic status
---------------------------
The Lean proof stack is machine-checked with respect to the concrete Lean model.
The correspondence between that model and the normative JavaScript/reference
source is source-audited, not itself a formal semantics proof of JavaScript.

Canonical post-stir semantics in this final stack use saved-sum semantics.

Before deleting local originals
-------------------------------
1. Upload this ZIP to an independent storage location.
2. Download it back once.
3. Verify its SHA-256 against the value supplied alongside the archive.
4. Only then delete the local source material.
